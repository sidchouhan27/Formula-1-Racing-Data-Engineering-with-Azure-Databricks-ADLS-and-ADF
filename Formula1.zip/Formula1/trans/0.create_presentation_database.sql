-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_presentation 
LOCATION "abfss://presentation@formula1dl627.dfs.core.windows.net/"